#include <ArduinoJson.h>
#include <DallasTemperature.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <ctype.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

// Replace these placeholders before uploading. Use a dedicated Firebase user
// for the device and restrict its database write access to this device's path.
const char *WIFI_SSID = "YOUR_WIFI_SSID";
const char *WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char *FIREBASE_DATABASE_URL =
    "https://scb-aeronix-default-rtdb.asia-southeast1.firebasedatabase.app";
const char *FIREBASE_WEB_API_KEY = "AIzaSyDdV0F9E8oboRLF7PqwKBp78sHTaNwzhEw";
const char *FIREBASE_DEVICE_EMAIL = "YOUR_DEVICE_USER_EMAIL";
const char *FIREBASE_DEVICE_PASSWORD = "YOUR_DEVICE_USER_PASSWORD";
const char *FIREBASE_DATA_PATH = "scb-aeronix/latest";

// Google Trust Services Root R1, used to validate Firebase HTTPS endpoints.
static const char FIREBASE_ROOT_CA[] PROGMEM = R"PEM(
-----BEGIN CERTIFICATE-----
MIIFVzCCAz+gAwIBAgINAgPlk28xsBNJiGuiFzANBgkqhkiG9w0BAQwFADBHMQsw
CQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExMQzEU
MBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMTYwNjIyMDAwMDAwWhcNMzYwNjIyMDAw
MDAwWjBHMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZp
Y2VzIExMQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwggIiMA0GCSqGSIb3DQEBAQUA
A4ICDwAwggIKAoICAQC2EQKLHuOhd5s73L+UPreVp0A8of2C+X0yBoJx9vaMf/vo
27xqLpeXo4xL+Sv2sfnOhB2x+cWX3u+58qPpvBKJXqeqUqv4IyfLpLGcY9vXmX7w
Cl7raKb0xlpHDU0QM+NOsROjyBhsS+z8CZDfnWQpJSMHobTSPS5g4M/SCYe7zUjw
TcLCeoiKu7rPWRnWr4+wB7CeMfGCwcDfLqZtbBkOtdh+JhpFAz2weaSUKK0Pfybl
qAj+lug8aJRT7oM6iCsVlgmy4HqMLnXWnOunVmSPlk9orj2XwoSPwLxAwAtcvfaH
szVsrBhQf4TgTM2S0yDpM7xSma8ytSmzJSq0SPly4cpk9+aCEI3oncKKiPo4Zor8
Y/kB+Xj9e1x3+naH+uzfsQ55lVe0vSbv1gHR6xYKu44LtcXFilWr06zqkUspzBmk
MiVOKvFlRNACzqrOSbTqn3yDsEB750Orp2yjj32JgfpMpf/VjsPOS+C12LOORc92
wO1AK/1TD7Cn1TsNsYqiA94xrcx36m97PtbfkSIS5r762DL8EGMUUXLeXdYWk70p
aDPvOmbsB4om3xPXV2V4J95eSRQAogB/mqghtqmxlbCluQ0WEdrHbEg8QOB+DVrN
VjzRlwW5y0vtOUucxD/SVRNuJLDWcfr0wbrM7Rv1/oFB2ACYPTrIrnqYNxgFlQID
AQABo0IwQDAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
FgQU5K8rJnEaK0gnhS9SZizv8IkTcT4wDQYJKoZIhvcNAQEMBQADggIBAJ+qQibb
C5u+/x6Wki4+omVKapi6Ist9wTrYggoGxval3sBOh2Z5ofmmWJyq+bXmYOfg6LEe
QkEzCzc9zolwFcq1JKjPa7XSQCGYzyI0zzvFIoTgxQ6KfF2I5DUkzps+GlQebtuy
h6f88/qBVRRiClmpIgUxPoLW7ttXNLwzldMXG+gnoot7TiYaelpkttGsN/H9oPM4
7HLwEXWdyzRSjeZ2axfG34arJ45JK3VmgRAhpuo+9K4l/3wV3s6MJT/KYnAK9y8J
ZgfIPxz88NtFMN9iiMG1D53Dn0reWVlHxYciNuaCp+0KueIHoI17eko8cdLiA6Ef
MgfdG+RCzgwARWGAtQsgWSl4vflVy2PFPEz0tv/bal8xa5meLMFrUKTX5hgUvYU/
Z6tGn6D/Qqc6f1zLXbBwHSs09dR2CQzreExZBfMzQsNhFRAbd03OIozUhfJFfbdT
6u9AWpQKXCBfTkBdYiJ23//OYb2MI3jSNwLgjt7RETeJ9r/tSQdirpLsQBqvFAnZ
0E6yove+7u7Y/9waLd64NnHi/Hm3lCXRSHNboTXns5lndcEZOitHTtNCjv0xyBZm
2tIMPNuzjsmhDYAPexZ3FL//2wmUspO8IFgV6dtxQ/PeEMMA3KgqlbbC1j+Qa3bb
bP6MvPJwNQzcmRk13NfIRmPVNnGuV/u3gm3c
-----END CERTIFICATE-----
)";

constexpr int MOISTURE_PIN = 34;  // ADC1, input only
constexpr int PH_PIN = 35;        // ADC1, input only
constexpr int ONE_WIRE_PIN = 4;
constexpr int RELAY_PIN = 26;
constexpr bool RELAY_ACTIVE_LOW = true;

// Calibrate these ADC readings with the actual moisture probe in dry and wet media.
constexpr int MOISTURE_DRY_RAW = 3000;
constexpr int MOISTURE_WET_RAW = 1400;

// Calibrate PH_NEUTRAL_VOLTAGE and VOLTS_PER_PH using pH buffer solutions.
constexpr float PH_NEUTRAL_VOLTAGE = 2.50f;
constexpr float VOLTS_PER_PH = 0.18f;

constexpr float FAN_MOISTURE_ON_PERCENT = 60.0f;
constexpr float FAN_TEMPERATURE_ON_C = 60.0f;
constexpr unsigned long PUBLISH_INTERVAL_MS = 3000;
constexpr unsigned long WIFI_RETRY_INTERVAL_MS = 10000;

OneWire oneWire(ONE_WIRE_PIN);
DallasTemperature temperatureProbe(&oneWire);

String databaseUrl;
String idToken;
String refreshToken;
unsigned long tokenExpiresAt = 0;
unsigned long lastPublishAt = 0;
unsigned long lastWifiAttemptAt = 0;
bool fanOn = false;

String urlEncode(const String &value) {
  String encoded;
  char hex[4];
  for (size_t i = 0; i < value.length(); ++i) {
    const unsigned char c = static_cast<unsigned char>(value[i]);
    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
      encoded += static_cast<char>(c);
    } else {
      snprintf(hex, sizeof(hex), "%%%02X", c);
      encoded += hex;
    }
  }
  return encoded;
}

bool postHttps(const String &url, const String &contentType,
               const String &body, String &responseBody) {
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;

  if (!http.begin(client, url)) {
    Serial.println("HTTPS request initialization failed.");
    return false;
  }

  http.addHeader("Content-Type", contentType);
  const int statusCode = http.POST(body);
  responseBody = http.getString();
  http.end();

  if (statusCode < 200 || statusCode >= 300) {
    Serial.printf("HTTPS POST failed with HTTP %d: %s\n",
                  statusCode, responseBody.c_str());
    return false;
  }
  return true;
}

bool parseAuthResponse(const String &responseBody, bool isRefresh) {
  StaticJsonDocument<3072> response;
  const DeserializationError error = deserializeJson(response, responseBody);
  if (error) {
    Serial.printf("Could not parse Firebase Auth response: %s\n", error.c_str());
    return false;
  }

  const char *newIdToken = isRefresh
      ? response["id_token"] | ""
      : response["idToken"] | "";
  const char *newRefreshToken = isRefresh
      ? response["refresh_token"] | ""
      : response["refreshToken"] | "";
  const char *expiresInText = isRefresh
      ? response["expires_in"] | "3600"
      : response["expiresIn"] | "3600";
  if (newIdToken[0] == '\0' || newRefreshToken[0] == '\0') {
    Serial.println("Firebase Auth response did not contain tokens.");
    return false;
  }

  idToken = newIdToken;
  refreshToken = newRefreshToken;
  if (!isRefresh) {
    const char *deviceUid = response["localId"] | "";
    if (deviceUid[0] != '\0') {
      Serial.printf("Firebase device UID (use to restrict database writes): %s\n",
                    deviceUid);
    }
  }
  const unsigned long expiresInSeconds = strtoul(expiresInText, nullptr, 10);
  const unsigned long refreshEarlySeconds = expiresInSeconds > 120 ? 60 : 0;
  tokenExpiresAt = millis() + (expiresInSeconds - refreshEarlySeconds) * 1000UL;
  return true;
}

bool signInToFirebase() {
  StaticJsonDocument<256> request;
  request["email"] = FIREBASE_DEVICE_EMAIL;
  request["password"] = FIREBASE_DEVICE_PASSWORD;
  request["returnSecureToken"] = true;
  String requestBody;
  serializeJson(request, requestBody);

  String responseBody;
  const String url =
      String("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=") +
      FIREBASE_WEB_API_KEY;
  if (!postHttps(url, "application/json", requestBody, responseBody)) return false;
  return parseAuthResponse(responseBody, false);
}

bool refreshFirebaseToken() {
  if (refreshToken.length() == 0) return signInToFirebase();

  const String body = String("grant_type=refresh_token&refresh_token=") +
      urlEncode(refreshToken);
  String responseBody;
  const String url = String("https://securetoken.googleapis.com/v1/token?key=") +
      FIREBASE_WEB_API_KEY;
  if (!postHttps(url, "application/x-www-form-urlencoded", body, responseBody)) {
    return false;
  }
  return parseAuthResponse(responseBody, true);
}

bool ensureFirebaseToken() {
  if (idToken.length() == 0) return signInToFirebase();
  if (static_cast<int32_t>(millis() - tokenExpiresAt) >= 0) {
    return refreshFirebaseToken();
  }
  return true;
}

void connectToWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  Serial.printf("Connecting to Wi-Fi: %s\n", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  lastWifiAttemptAt = millis();

  const unsigned long startAt = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startAt < 20000) {
    delay(250);
    Serial.print('.');
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("Wi-Fi connected; IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("Wi-Fi connection timed out; retrying in the loop.");
  }
}

int readAveragedAdc(int pin) {
  uint32_t total = 0;
  constexpr int SAMPLE_COUNT = 10;
  for (int i = 0; i < SAMPLE_COUNT; ++i) {
    total += analogRead(pin);
    delay(2);
  }
  return static_cast<int>(total / SAMPLE_COUNT);
}

float readMoisturePercent(int rawValue) {
  const float percent =
      (MOISTURE_DRY_RAW - rawValue) * 100.0f /
      (MOISTURE_DRY_RAW - MOISTURE_WET_RAW);
  return constrain(percent, 0.0f, 100.0f);
}

float readPhValue(int rawValue) {
  const float voltage = rawValue * (3.3f / 4095.0f);
  return constrain(7.0f + (PH_NEUTRAL_VOLTAGE - voltage) / VOLTS_PER_PH,
                   0.0f, 14.0f);
}

void setFan(bool on) {
  fanOn = on;
  const bool relayLevel = RELAY_ACTIVE_LOW ? !fanOn : fanOn;
  digitalWrite(RELAY_PIN, relayLevel ? HIGH : LOW);
}

String getFanReason(float moisture, float temperature) {
  const bool moistureTrigger = moisture > FAN_MOISTURE_ON_PERCENT;
  const bool temperatureTrigger = temperature > FAN_TEMPERATURE_ON_C;
  if (moistureTrigger && temperatureTrigger) {
    return "Moisture above 60%; temperature above 60 C";
  }
  if (moistureTrigger) return "Moisture above 60%";
  if (temperatureTrigger) return "Temperature above 60 C";
  return "Conditions within target range";
}

bool publishReading(float moisture, float temperature, float ph) {
  if (!ensureFirebaseToken()) {
    Serial.println("Firebase authentication unavailable; reading not uploaded.");
    return false;
  }

  const time_t epochSeconds = time(nullptr);
  if (epochSeconds < 1700000000) {
    Serial.println("Waiting for NTP time sync before publishing lastUpdated.");
    return false;
  }

  StaticJsonDocument<384> reading;
  reading["moisture"] = moisture;
  reading["temperature"] = temperature;
  reading["ph"] = ph;
  reading["fanState"] = fanOn;
  reading["fanReason"] = getFanReason(moisture, temperature);
  reading["lastUpdated"] =
      static_cast<uint64_t>(epochSeconds) * static_cast<uint64_t>(1000);
  String requestBody;
  serializeJson(reading, requestBody);

  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;
  const String url = databaseUrl + "/" + FIREBASE_DATA_PATH +
      ".json?auth=" + idToken;

  if (!http.begin(client, url)) {
    Serial.println("Could not initialize Firebase Realtime Database request.");
    return false;
  }

  http.addHeader("Content-Type", "application/json");
  const int statusCode = http.PUT(requestBody);
  const String responseBody = http.getString();
  http.end();

  if (statusCode < 200 || statusCode >= 300) {
    Serial.printf("Firebase write failed with HTTP %d: %s\n",
                  statusCode, responseBody.c_str());
    return false;
  }
  Serial.printf("Uploaded sensor reading: %s\n", requestBody.c_str());
  return true;
}

void setup() {
  Serial.begin(115200);

  pinMode(RELAY_PIN, OUTPUT);
  setFan(false);

  analogReadResolution(12);
  analogSetPinAttenuation(MOISTURE_PIN, ADC_11db);
  analogSetPinAttenuation(PH_PIN, ADC_11db);
  temperatureProbe.begin();

  databaseUrl = FIREBASE_DATABASE_URL;
  while (databaseUrl.endsWith("/")) {
    databaseUrl.remove(databaseUrl.length() - 1);
  }

  connectToWiFi();
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  Serial.println("ESP32 compost monitor started.");
}

void loop() {
  const unsigned long now = millis();
  if (WiFi.status() != WL_CONNECTED) {
    if (now - lastWifiAttemptAt >= WIFI_RETRY_INTERVAL_MS) connectToWiFi();
    delay(50);
    return;
  }
  if (now - lastPublishAt < PUBLISH_INTERVAL_MS) {
    delay(50);
    return;
  }
  lastPublishAt = now;

  const int moistureRaw = readAveragedAdc(MOISTURE_PIN);
  const int phRaw = readAveragedAdc(PH_PIN);
  temperatureProbe.requestTemperatures();
  const float temperature = temperatureProbe.getTempCByIndex(0);

  if (temperature == DEVICE_DISCONNECTED_C || !isfinite(temperature)) {
    Serial.println("DS18B20 reading unavailable; keeping the current relay state.");
    return;
  }

  const float moisture = readMoisturePercent(moistureRaw);
  const float ph = readPhValue(phRaw);
  setFan(moisture > FAN_MOISTURE_ON_PERCENT ||
         temperature > FAN_TEMPERATURE_ON_C);

  Serial.printf("Moisture: %.1f%%, Temperature: %.1f C, pH: %.2f, Fan: %s (%s)\n",
                moisture, temperature, ph, fanOn ? "ON" : "OFF",
                getFanReason(moisture, temperature).c_str());
  publishReading(moisture, temperature, ph);
}
